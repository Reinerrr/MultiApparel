﻿using System.Collections.Generic;
using Verse;
using RimWorld;
using System.Linq;

namespace MultiApparel
{
    public class PawnStatData : IExposable
    {
        public Pawn pawn;
        public Dictionary<StatDef, int> weights = new Dictionary<StatDef, int>();

        public void ExposeData()
        {
            Scribe_References.Look(ref pawn, "pawn");
            Scribe_Collections.Look(ref weights, "weights", LookMode.Def, LookMode.Value);
        }
    }

    public class WorkRoleApparelManager : GameComponent
    {
        public List<PawnStatData> allPawnData = new List<PawnStatData>();
        public List<StatDef> trackedStats = new List<StatDef>();

        public WorkRoleApparelManager(Game game) : base()
        {
            CacheTrackedStats();
        }

        private void CacheTrackedStats()
        {
            var stats = new HashSet<StatDef>();
            foreach (var thingDef in DefDatabase<ThingDef>.AllDefsListForReading)
            {
                if (!thingDef.IsApparel) continue;
                if (thingDef.statBases != null)
                    foreach (var statBase in thingDef.statBases)
                        if (statBase.stat != null) stats.Add(statBase.stat);

                var offsetsField = thingDef.GetType().GetField("equippedStatOffsets");
                if (offsetsField != null)
                {
                    var offsets = offsetsField.GetValue(thingDef) as System.Collections.IEnumerable;
                    if (offsets != null)
                        foreach (var mod in offsets)
                        {
                            var statProp = mod.GetType().GetField("stat");
                            if (statProp != null)
                            {
                                var stat = statProp.GetValue(mod) as StatDef;
                                if (stat != null) stats.Add(stat);
                            }
                        }
                }
            }
            trackedStats = stats.OrderBy(s => s.label).ToList();
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref allPawnData, "allPawnData", LookMode.Deep);
        }

        public int GetWeight(Pawn pawn, StatDef stat)
        {
            var data = allPawnData.Find(x => x.pawn == pawn);
            if (data != null && data.weights.TryGetValue(stat, out int weight))
                return weight;
            return 5;
        }

        public void SetWeight(Pawn pawn, StatDef stat, int weight)
        {
            var data = allPawnData.Find(x => x.pawn == pawn);
            if (data == null)
            {
                data = new PawnStatData { pawn = pawn };
                allPawnData.Add(data);
            }
            data.weights[stat] = weight;
        }
    }
}